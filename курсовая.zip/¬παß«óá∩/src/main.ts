import path from "path"
import readline from "readline"
import { insertingSchedule, insertHTML, clearCollection } from "./Mongo"
import { parseSchedule } from "./parsSheduleOfCouples"
import fs from "fs"

const CommandLine = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})

// askQuestion задает пользователю вопрос query и возвращает введенное значение
const askQuestion = (question: string): Promise<string> => {
    return new Promise(resolve => CommandLine.question(question, resolve))
}


export const nameComparison: { [key: string]: string } = {
    "1": "teacher",
    "2": "group",
    "3": "classroom",
    "4": "lessonType",
    "5": "week",
    "6": "subjectName",
}

const main = async () => {
    const dirPath = "C:\\Users\\kuche\\Desktop\\курсовая\\src"
    const files = fs.readdirSync(dirPath).filter(file => file.endsWith(".xlsx"))
    if (files.length === 0) {
        console.log("\x1b[31mВ указанной директории нет файлов с форматом 'xlsx'!\x1b[0m")
        CommandLine.close()
        return
    }

    console.log("\n")

    // Очистка коллекции перед импортом расписания
    await clearCollection()

    // Импорт расписания из файлов
    for (const file of files) {
        const filePath = path.resolve(dirPath, file)
            const schedule = await parseSchedule(filePath)
            await insertingSchedule(schedule)
    }

    // Сообщение об успешном импорте
    console.log("\x1b[32mРасписание кафедры 'АВТОМАТИКА И СИСТЕМЫ УПРАВЛЕНИЯ' успешно импортировано!\x1b[0m")

    let checkNumberOfConditions: number
    while (true) {
        console.log("\nВозможные критерии для поиска:\n1 - Поиск по преподавателю.\n2 - Поиск по группе.\n3 - Поиск по аудитории.")
        console.log("4 - Поиск по типу предмета (лек., пр.кср., лаб.).\n5 - Поиск по типу недели (четная, нечетная).\n6 - Поиск по предмету.\n")
        const numberOfConditions = await askQuestion("Укажите количество условий для поиска: ")
        checkNumberOfConditions = parseInt(numberOfConditions, 10)
        if (!isNaN(checkNumberOfConditions) && checkNumberOfConditions > 0) {
            break
        }
        console.log("\x1b[31mКоличество условий для поиска не может быть отрицательным!\x1b[0m")
    }
    const criteria = []
    for (let i = 0; i < checkNumberOfConditions; i++) {
        let type: string
        while (true) {
            type = (await askQuestion("Введите условие для поиска: ")).toLowerCase()
            if (nameComparison[type]) {
                break
            }
            console.log("\x1b[31mВведенного условия не существует!\x1b[0m")
        }
        const value = await askQuestion("Введите значение условия для поиска: ")
        criteria.push({ type: nameComparison[type], value })
    }
    await insertHTML(criteria)
    CommandLine.close()
}
main().catch(console.error)