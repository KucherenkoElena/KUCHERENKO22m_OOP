import ExcelJS from "exceljs"

export interface Couple {
  time: string             // Время пары
  group: string            // Номер группы
  classroom: string        // Номер аудитории
  lessonType: string       // Тип занятия
  subjectName: string      // Название предмета
  teacher: string          // ФИО преподавателя
  department: string       // Название кафедры
}

export interface Schedule {
  week: string
  days: {
      day: string;
      lessons: Couple[]
  }[];
}

const gettingTheValue = (cellValue: string): { group: string; classroom: string } => {
  const spaceIndex = cellValue.indexOf(" ")
  let group = ""
  let classroom = ""
  if (spaceIndex !== -1) {
      group = cellValue.slice(0, spaceIndex)
      classroom = cellValue.slice(spaceIndex + 1).trim()
  } else {
    group = cellValue
  }
  return { group, classroom }
}

const getTheValueCorrectly = (cellValue: string): { lessonType: string; subjectName: string } => {
  let lessonType = ""
  let subjectName = ""
  if (cellValue.includes("кср.")) {
    const index = cellValue.indexOf("кср.")
    lessonType = cellValue.substring(0, index + 4).trim()
    subjectName = cellValue.substring(index + 4).trim()
  } else if (cellValue.includes("пр.")) {
    const index = cellValue.indexOf("пр.")
    lessonType = cellValue.substring(0, index + 3).trim()
    subjectName = cellValue.substring(index + 3).trim()
  } else if (cellValue.includes("лаб.") || cellValue.includes("лек.")) {
    lessonType = cellValue.substring(0, cellValue.indexOf(".") + 1).trim()
    subjectName = cellValue.substring(cellValue.indexOf(".") + 1).trim()
  } else if (cellValue.includes("электрон.") || cellValue.includes("схемотех.")) {
    lessonType = "пр."
    subjectName = cellValue.trim()
  } else if (cellValue.includes("кураторск")) {
    lessonType = "   "
    subjectName = cellValue.trim()
  } else {
      const [type, ...nameParts] = cellValue.split(".")
      lessonType = type.trim()
      subjectName = nameParts.join(".").trim()
  }
  return { lessonType, subjectName }
}

export const parseSchedule = async (filePath: string): Promise<Schedule[]> => {
  const workbook = new ExcelJS.Workbook()
  await workbook.xlsx.readFile(filePath)
  const worksheet = workbook.worksheets[0]
  const schedule: Schedule[] = []
  const daysOfTheWeek = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота"]
  for (let lineIndex = 7; lineIndex < worksheet.rowCount; lineIndex += 32) {
    let weekType = "четная"
    const teacherCell = worksheet.getRow(lineIndex).getCell(2)
    const teacher = teacherCell.value ? teacherCell.value.toString() : ""
    const departmentCell = worksheet.getRow(lineIndex).getCell(3)
    const department = departmentCell.value ? departmentCell.value.toString() : ""
    const getLessonForDay = (dayIndex: number, value: number): Couple[] => {
      const lessons: Couple[] = []
      for (let i = value; i < 20; i += 4) {
        const rowtime = worksheet.getRow(lineIndex + i + 2)
        const celltime = rowtime.getCell(1)
        const couplesTime = celltime.value ? celltime.value.toString() : ""
        const row1 = worksheet.getRow(lineIndex + i + 2)
        const firstCell = row1.getCell(dayIndex + 2)
        let cellValue1 = firstCell.value ? firstCell.value.toString() : ""
        let get1 = gettingTheValue(cellValue1)
        const row2 = worksheet.getRow(lineIndex + i + 3)
        let secondCell = row2.getCell(dayIndex + 2)
        let cellValue2 = secondCell.value ? secondCell.value.toString() : ""
        let get2 = getTheValueCorrectly(cellValue2)
        if (get1.group.includes(".")) {
          const rowAbove = worksheet.getRow(lineIndex + i + 1)
          const cellAbove = rowAbove.getCell(dayIndex + 2)
          cellValue1 = cellAbove.value ? cellAbove.value.toString() : ""
          get1 = gettingTheValue(cellValue1)
          const rowBelow = worksheet.getRow(lineIndex + i + 2)
          const cellBelow = rowBelow.getCell(dayIndex + 2)
          cellValue1 = cellBelow.value ? cellBelow.value.toString() : ""
          get2 = getTheValueCorrectly(cellValue2)
        }
        const couple: Couple = {
          time: couplesTime,
          teacher: teacher,
          department: department,
          ...get1,
          ...get2
        }
        lessons.push(couple)
      }
      return lessons
    }
    for (let k = 0; k < 3; k += 2) {
      if (k === 0) weekType = "четная"
      else weekType = "нечетная"
      const newSchedule: Schedule = {
          week: weekType,
          days: daysOfTheWeek.map((day, index) => ({
            day: day,
            lessons: getLessonForDay(index, k)
          }))
      }
      schedule.push(newSchedule)
    }
  }
  return schedule
}