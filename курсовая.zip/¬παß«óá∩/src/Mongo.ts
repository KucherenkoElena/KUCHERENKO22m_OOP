import { MongoClient } from "mongodb"
import { writeFileSync } from "fs"
import { Schedule } from "./parsSheduleOfCouples"

const CONNECTION = "mongodb://root:example@127.0.0.1:27017/"
const client = new MongoClient(CONNECTION, { monitorCommands: true })

export const insertingSchedule = async (schedule: Schedule[]) => {
    try {
        await client.connect()
        const db = client.db("KRB")
        const collection = db.collection("Lesson")
        await collection.insertMany(schedule)
        console.log("...")
    } 
    catch (error) {
        console.error("Ошибка при вставке расписания в базу данных", error)
        throw error
    } 
    finally {
        await client.close()
    }
}

export const getSchedule2 = async (criteria: { type: string; value: string }) => {
    try {
        await client.connect()
        const db = client.db("KRB")
        const collection = db.collection("Lesson")
        const { type, value } = criteria
        const daysOfWeek = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота"]
        let matchCondition
        if (type === "week") {
            matchCondition = { week: value }
        } 
        else {
            matchCondition = {
                $or: daysOfWeek.map(day => ({
                    [`days.day`]: day,
                    [`days.lessons.${type}`]: { $regex: new RegExp(`(^|;|~)${value}($|;|~)`, "i") }
                }))
            }
        }
        const schedule = await collection.aggregate([
            { $match: matchCondition },
            { $unwind: "$days" },
            { $unwind: "$days.lessons" },
            {
                $match: type === "week" ? {} : {
                    [`days.lessons.${type}`]: { $regex: new RegExp(`(^|;|~)${value}($|;|~)`, "i") }
                }
            },
            {
                $addFields: {
                    dayOfWeekNumber: { $indexOfArray: [daysOfWeek, "$days.day"] }
                }
            },
            {
                $project: {
                    week: 1,
                    dayOfWeek: "$days.day",
                    dayOfWeekNumber: { $add: ["$dayOfWeekNumber", 1] },
                    time: "$days.lessons.time",
                    teacher: "$days.lessons.teacher",
                    group: "$days.lessons.group",
                    classroom: "$days.lessons.classroom",
                    lessonType: "$days.lessons.lessonType",
                    subjectName: "$days.lessons.subjectName"
                }
            },
            { $sort: { week: 1, dayOfWeekNumber: 1, time: 1 } }
        ]).toArray()
        return schedule
    } 
    catch (error) {
        console.error("Ошибка при получении расписания", error)
        throw error
    } 
    finally {
        await client.close()
    }
}

const designations: { [key: string]: string } = {
    dayOfWeek: "День недели",
    time: "Время",
    teacher: "Преподаватель",
    group: "Группа",
    classroom: "Аудитория",
    lessonType: "Тип предмета",
    subjectName: "Предмет"
}

function forBeautyHTML(schedule: any[], criteria: { type: string; value: string }[]) {
    const excludeColumns = criteria.map(c => c.type)
    let htmlContent = '<html><head><title>Schedule</title>'
    htmlContent += '<link rel="stylesheet" type="text/css" href="styles.css">'
    htmlContent += '<style>'
    htmlContent += '.week td { color: #0000FF}'
    htmlContent += '.criteria { color: #FF0000 }'
    htmlContent += '</style>'
    htmlContent += '</head><body>'
    htmlContent += `<h1>Расписание: <span class="criteria">${criteria.map(({ value }) => `${value}`).join(', ')}</span></h1>`
    htmlContent += '<table border="1"><tr>'
    for (const key in designations) {
        if (!excludeColumns.includes(key)) {
            htmlContent += `<th>${designations[key]}</th>`
        }
    }
    htmlContent += "</tr>"
    schedule.forEach(entry => {
        htmlContent += `<tr class="${entry.week === "нечетная" ? "week" : ""}">`
        for (const key in designations) {
            if (!excludeColumns.includes(key)) {
                htmlContent += `<td>${entry[key]}</td>`
            }
        }
        htmlContent += "</tr>"
    })
    htmlContent += "</table></body></html>"
    return htmlContent
}

export async function insertHTML(criteria: { type: string; value: string }[]) {
    try {
        let schedule: any[] = []
        for (const criterion of criteria) {
            const currentSchedule = await getSchedule2(criterion)
            if (schedule.length === 0) {
                schedule = currentSchedule
            } else {
                schedule = schedule.filter(entry =>
                    currentSchedule.some(
                        ({ week, dayOfWeek, time, teacher, group, classroom, lessonType, subjectName }) =>
                            entry.week === week &&
                            entry.dayOfWeek === dayOfWeek &&
                            entry.time === time &&
                            entry.teacher === teacher &&
                            entry.group === group &&
                            entry.classroom === classroom &&
                            entry.lessonType === lessonType &&
                            entry.subjectName === subjectName
                    )
                )
            }
        }
        const htmlContent = forBeautyHTML(schedule, criteria)
        const filePath = "scheduleCouple.html"
        writeFileSync(filePath, htmlContent)
        console.log(`\n\x1b[32mРасписание добавлено в файл '${filePath}'\x1b[0m`)
    } 
    catch (error) {
        console.error("Ошибка вывода расписания:", error)
    }
}

export const clearCollection = async () => {
    try {
        await client.connect()
        const database = client.db("KRB")
        const collection = database.collection("Lesson")
        await collection.deleteMany({})
    } 
    finally {
        await client.close()
    }
}

export const clearDepartment = async (department: string): Promise<boolean> => {
    try {
        await client.connect()
        const database = client.db("KRB")
        const collection = database.collection("Lesson")
        const result = await collection.deleteMany({ "days.lessons.department": department })
        return result.deletedCount > 0
    } 
    finally {
        await client.close()
    }
}