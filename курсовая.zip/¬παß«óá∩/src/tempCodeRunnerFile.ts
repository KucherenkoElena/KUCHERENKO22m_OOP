} else {
    //     const fileIndices = fileIndicesStr.split(",").map(indexStr => parseInt(indexStr.trim(), 10) - 1)
    //     for (const index of fileIndices) {
    //         if (index >= 0 && index < files.length) {
    //             const filePath = path.resolve(dirPath, files[index])
    //                 const schedule = await parseSchedule(filePath)
    //                 if (schedule.length > 0 && schedule[0].days.length > 0 && schedule[0].days[0].lessons.length > 0) {
    //                     const department = schedule[0].days[0].lessons[0].department
    //                     await clearDepartment(department)
    //                     await insertScheduleToDB(schedule)
    //                 } else {
    //                     console.log(`Расписание из файла ${files[index]} пустое.`)
    //                 }
    //                 console.log(`Расписание из файла ${files[index]} успешно добавлено в базу данных.`)
    //         }
    //     }
    // } 